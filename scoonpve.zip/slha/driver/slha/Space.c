#ident	"@(#)Space.c	3.1.1.12"

/*+++HDR
 *          Name:  Space.c 
 *         Title:  
 *     $Workfile: 
 *     $Revision:
 *      $Modtime:
 *    Programmer:
 * Creation Date:
 *
 *  Version History
 *  ---------------
 *
 *    Date    Who?  Description
 *  --------  ----  -------------------------------------------------------
 *
 *-------------------------------------------------------------------------
 *
 *  $Header:   $
 *  $Log:      $
 *
 *
---*/

#define SCO
#ifdef UWARE
#include <sys/types.h>
#include <sys/sdi_edt.h>
#include <sys/sdi.h>
#include <sys/scsi.h>
#endif  /* UWARE */
#include <sys/conf.h>

char	c8xx_Version[] = "slha 4.11.03";
char	DRIVER_VERSION[]="41103";

/************************************************************************
 * These are the tuning parameters set using idtune parameters.
 * c8xx_QDEPTH :
 *      Minimum value = 0             Maximum value = 128
 *      Defines the number of qtags supported by the device driver.
 ***********************************************************************/

unsigned char	c8xx_QDEPTH = 5;
int		c8xx_CCBS = 500;

#ifdef UWARE
#define	MAX_HBA	SDI_MAX_HBAS-1;
char	c8xx_modname[] = "c8xx";		/* driver modname */

void	*c8xx_HBAs[SDI_MAX_HBAS] = {NULL};
#define	C8XX_VERSION	HBA_UW21_IDATA | HBA_EXT_ADDRESS

/*
 * Change the name of the original idata array in space.c.
 * We do this so we don't have to change all references
 * to the original name in the driver code.
 */
struct	hba_idata_v5	_c8xxidata[]	= {
	{ C8XX_VERSION, "(c8xx,1) Symbios c8xx 4.11.03",
	  7, 0, -1, 0, -1, 0 }
};
#else   /* not UWARE */
#include "sys/devreg.h"
#define	MAX_HBA	31
SHAREG_EX drvrreg[MAX_HBA+1];
int drvr_processor = DRIVER_CPU_DEFAULT;
unsigned char	numHBAs = 0;
void	*c8xx_HBAs[MAX_HBA+1] = {0};
#endif  /* not UWARE */

/* tuneable Parameters */
unsigned char c8xx_MAX_LUN = 31;
unsigned char c8xx_SelectionTimeoutFactor = 0;  /* 0 = 204.8 millisec
                                                   1 = 409.6 millisec
                                                   2 = 819.2 millisec */
unsigned short c8xx_max_command_timeout = 1200;  /* Seconds */
unsigned char c8xx_TapeCmdTimeoutScale = 1;  /* Tape Command Timeout Scale
					Factor (ArcServe Workaround) */
unsigned char c8xx_Debug_Verbose_Level = 0;
unsigned char c8xx_DoDomainValidation = 0; 
/* only in effect if Nvram and Nvs are not available */
unsigned char c8xx_InitializationResetsBus = 1;
unsigned char c8xx_InitiatorID = 7;
unsigned char c8xx_ScanExcludeID = 16;
unsigned char c8xx_do_tagged = 1;
